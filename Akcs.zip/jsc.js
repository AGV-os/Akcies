let sastr = 10000;
let akc = 3;
let randInt = Math.floor(Math.random() * (100000 - 100 + 1)) + 100;
let akcStoim = randInt;
stoimost()
function update(){
    akcStoim = Math.floor(Math.random() * (100000 - 100 + 1)) + 100;
    document.getElementById("stoim").innerText = "Стоимость акций: " + akcStoim
    
}
function buy(){
    if(sastr>=akcStoim){
        akc += 1
        sastr -= akcStoim
        document.getElementById("akc").innerText = "Акции: " + akc
        stoimost()
    }
}
function stoimost(){
    document.getElementById("stoim").innerText = "Стоимость акции: " + akcStoim
    document.getElementById("sost").innerText = "Ваше состояние оцениваеться в " + sastr + "₽"
    document.getElementById("akc").innerText = "у вас " + akc + " акции"
}
stoimost()
function sale(){
    if(akc>0){
        akc -= 1
        sastr += akcStoim
        stoimost()
    }
}

